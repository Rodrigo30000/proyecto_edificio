import React from 'react'

export const Home = () => {
  return (
    <div className='text-3xl text-blue-500'>Home</div>
  )
}
